# D2 Estimate Studio Project

This folder contains the estimate app files created for D2 Carpentry & Design.

## Main Files

- `index.html` opens the estimator locally.
- `alchemyist-estimate-studio.zip` is the hosting/upload package.
- `HOSTING.md` explains how to host the app and connect it from Wix.
- `app.js` controls the estimator behavior.
- `styles.css` controls the visual design and PDF/print styling.
- `assets/d2-logo.png` is the D2 logo used in the estimate.

## Current Hosting Plan

Host this folder with GitHub Pages, then link to the live GitHub Pages URL from a hidden Wix page.

Recommended hidden Wix URL:
`https://www.thealchemyist.com/estimate-studio`

## GitHub Pages Setup

1. Create a new GitHub repository.
2. Upload or push these project files to the repository.
3. In GitHub, open the repository settings.
4. Go to `Pages`.
5. Set the source to `Deploy from a branch`.
6. Choose the `main` branch and `/root`.
7. GitHub will create a live URL for the estimator.

## Later Features

`google-apps-script-backend.js` is saved for later when the app is ready to connect to Google Drive, Google Sheets, and email.
